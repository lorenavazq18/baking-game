import pygame

def wall_collision(x, y, vx, vy, radius, obstacles):
    #update x and check  x walls 
    x += vx
    rect = pygame.Rect(x - radius, y - radius, radius * 2, radius * 2)
    for obstacle in obstacles:
        if rect.colliderect(obstacle):
            if vx > 0:
                x = obstacle.left - radius
            elif vx < 0:
                x = obstacle.right + radius
            vx = 0
            break
    #update y and check y walls
    y += vy
    rect = pygame.Rect(x - radius, y - radius, radius *2, radius * 2)
    for obstacle in obstacles:
        if rect.colliderect(obstacle):
            if vy > 0:
                y = obstacle.top - radius
            elif vy < 0:
                y = obstacle.bottom + radius
            vy = 0 
            break
    #screen limtis
    if x < radius: x = radius; vx = 0
    if x > 640 - radius: x = 640 - radius; vx = 0
    if y < radius: y = radius; vy = 0
    if y > 600 - radius: y = 600 - radius; vy = 0

    return x, y, vx, vy