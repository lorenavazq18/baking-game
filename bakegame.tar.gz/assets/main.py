import pygame  # collisions, game controllers, keyboard input, etc..
import math
import os 
import asyncio  # async loop for publish

# importing python files 
from config import * 
from engine import wall_collision
from interactions import handle_inter
from player import __init__

# UPCOMING TASKS:
# add background image and make sure that sprites, obstacles & distractions are layered ON TOP of the background screen
# add distractions list - once players interact with them:
#       (1)they will become slower
#       (2)get time taken off
#       (3)OR force them to do another task (like clean)

pygame.init()  # initializes pygame

pygame.mixer.init()

pygame.mixer.music.load(
    os.path.join("assets", "music", "bossa-nova.mp3")
)

pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play(-1)  # loop


font = pygame.font.Font(
    os.path.join("assets", "font", "Pixelify_Sans", "PixelifySans-VariableFont_wght.ttf"),
    18
)
p1_holding = None    
p2_holding = None

p1_interacted = False
p2_interacted = False

# track chop on counter
chop_counters = {"cutting": 0}

# mixing timer 
mixing_timer = {"start_time": None}

# oven timer
oven_timer = {"start_time": None}


screen = pygame.display.set_mode((screen_width, screen_height))  # game window
clock = pygame.time.Clock()  # pace of game
running = True  # game is running

# title Page
title_img = pygame.image.load(
    os.path.join("assets", "title-page3.png")
).convert_alpha()

title_img = pygame.transform.smoothscale(title_img, (500, 400))


# win page 
win_screen_img = pygame.image.load(
    os.path.join("assets", "win-screen.png")
).convert_alpha()

lose_screen_img = pygame.image.load(
    os.path.join("assets", "lost-screen.png")
).convert_alpha()

win_screen_img = pygame.transform.smoothscale(
    win_screen_img, (480, 326)
)

lose_screen_img = pygame.transform.smoothscale(
    lose_screen_img, (480, 326)
)

# player
player1_img = pygame.image.load(
    os.path.join("assets", "player1", "p1-idle-down2.png")
).convert_alpha()

p1_walk_down = [
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-down1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-down2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-down3.png")
    ).convert_alpha()
]

p1_idle_up = pygame.image.load(
    os.path.join("assets", "player1", "p1-idle-up.png")
).convert_alpha()

p1_walk_up = [
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-up1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-up2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-up3.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-up4.png")
    ).convert_alpha(),
]

p1_idle_left = pygame.image.load(
    os.path.join("assets", "player1", "p1-idle-left.png")
).convert_alpha()

p1_walk_left = [
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-left1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-left2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-left3.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-left4.png")
    ).convert_alpha()
]

p1_idle_right = pygame.image.load(
    os.path.join("assets", "player1", "p1-idle-right.png")
).convert_alpha()

p1_walk_right = [
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-right1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-right2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player1", "p1-walk-right3.png")
    ).convert_alpha()
]

player2_img = pygame.image.load(
    os.path.join("assets", "player2", "p2-idle-down2.png")
).convert_alpha()

p2_walk_down = [
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-down1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-down2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-down3.png")
    ).convert_alpha()
]

p2_idle_up = pygame.image.load(
    os.path.join("assets", "player2", "p2-idle-up.png")
).convert_alpha()

p2_walk_up = [
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-up1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-up2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-up3.png")
    ).convert_alpha()
]

p2_idle_left = pygame.image.load(
    os.path.join("assets", "player2", "p2-idle-left.png")
).convert_alpha()

p2_walk_left = [
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-left1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-left2.png")
    ).convert_alpha()
]

p2_idle_right = pygame.image.load(
    os.path.join("assets", "player2", "p2-idle-right.png")
).convert_alpha()

p2_walk_right = [
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-right1.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-right2.png")
    ).convert_alpha(),
    pygame.image.load(
        os.path.join("assets", "player2", "p2-walk-right3.png")
    ).convert_alpha()
]

player1_img = pygame.transform.scale(player1_img, (50, 65))
player2_img = pygame.transform.scale(player2_img, (50, 65))

# animation variables
p1_frame = 0
p1_animation_speed = 190
p1_last_update = pygame.time.get_ticks()

p2_frame = 0
p2_animation_speed = 190
p2_last_update = pygame.time.get_ticks()

# background image 
background_img = pygame.image.load(os.path.join("assets", "seventh-prayer.png"))
background_img = pygame.transform.scale(background_img, (screen_width, screen_height))

top_left_corner = pygame.Rect(top_left_corner_data)
top_left = pygame.image.load(os.path.join("assets", "top-left7.png"))
top_left = pygame.transform.scale(top_left, (60, 50))

top_right_corner = pygame.Rect(top_right_corner_data)
top_right_img = pygame.image.load(os.path.join("assets", "top-right2.png"))
top_right_img = pygame.transform.scale(top_right_img, (50, 50))

bottom_right_corner = pygame.Rect(bottom_right_corner_data)
bottom_right_img = pygame.image.load(os.path.join("assets", "bottom-right.png"))
bottom_right_img = pygame.transform.scale(bottom_right_img, (50, 50))

bottom_left_corner = pygame.Rect(bottom_left_corner_data)

trash = pygame.Rect(trash_data)
trash_img = pygame.image.load(
    os.path.join("assets", "trash1.png")
)
trash_img = pygame.transform.scale(trash_img, (50, 50))

left_counter = pygame.Rect(left_counter_data)
left_counter_img = pygame.image.load(os.path.join("assets", "left-counter6.png"))
left_counter_img = pygame.transform.scale(left_counter_img, (50, 100))

takeout_counter = pygame.Rect(takeout_data)
takeout_img = pygame.image.load(os.path.join("assets", "takeout-counter1.png"))
takeout_img = pygame.transform.scale(takeout_img, (50, 280))

flour = pygame.Rect(flour_data)
flour_img = pygame.image.load(os.path.join("assets", "flour-table.png"))
flour_img = pygame.transform.scale(flour_img, (80, 50))

fridge = pygame.Rect(fridge_data)
fridge_img = pygame.image.load(os.path.join("assets", "milk-table.png"))
fridge_img = pygame.transform.scale(fridge_img, (100, 50))

oven = pygame.Rect(oven_data)
oven_img = pygame.image.load(os.path.join("assets", "oven-counter.png"))
oven_img = pygame.transform.scale(oven_img, (100, 50))

top_counter = pygame.Rect(top_counter_data)
top_counter_img = pygame.image.load(os.path.join("assets", "top-counter3.png"))
top_counter_img = pygame.transform.scale(top_counter_img, (60, 50))

butter = pygame.Rect(butter_data)
butter_img = pygame.image.load(
    os.path.join("assets", "butter.png")
)
butter_img = pygame.transform.scale(butter_img, (50, 60))

cutting = pygame.Rect(cutting_data)
cutting_img = pygame.image.load(
    os.path.join("assets", "cutting-board.png")
)
cutting_img = pygame.transform.scale(cutting_img, (50, 100))

mixing = pygame.Rect(mixing_data)
mixing_img = pygame.image.load(
    os.path.join("assets", "mixing1.png")
)
mixing_img = pygame.transform.scale(mixing_img, (50, 100))

bottom_counter = pygame.Rect(bottom_counter_data)
bottom_counter_img = pygame.image.load(
    os.path.join("assets", "bottom-counter.png")
)
bottom_counter_img = pygame.transform.scale(bottom_counter_img, (50, 70))

sugar = pygame.Rect(sugar_data)
sugar_img = pygame.image.load(os.path.join("assets", "sugar-counter3.png"))
sugar_img = pygame.transform.scale(sugar_img, (60, 50))

strawberries = pygame.Rect(strawberries_data)
berry_img = pygame.image.load(os.path.join("assets", "strawberry-counter.png"))
berry_img = pygame.transform.scale(berry_img, (60, 50))

egg = pygame.Rect(egg_data)
egg_img = pygame.image.load(os.path.join("assets", "egg-test.png"))
egg_img = pygame.transform.scale(egg_img, (60, 50))

bottom1_space = pygame.Rect(bottom_counter_space1_data)
bottom1_space_img = pygame.image.load(
    os.path.join("assets", "end-counter.png")
)
bottom1_space_img = pygame.transform.scale(bottom1_space_img, (110, 50))

middle1 = pygame.Rect(middle_counter1_data)
middle1_img = pygame.image.load(os.path.join("assets", "middle1.png"))
middle1_img = pygame.transform.scale(middle1_img, (50, 50))

middle2 = pygame.Rect(middle_counter2_data)
middle2_img = pygame.image.load(os.path.join("assets", "middle2.png"))
middle2_img = pygame.transform.scale(middle2_img, (50, 50))

middle3 = pygame.Rect(middle_counter3_data)
middle3_img = pygame.image.load(os.path.join("assets", "middle3.png"))
middle3_img = pygame.transform.scale(middle3_img, (50, 50))

# INGREDIENT ITEM IMAGES
flour_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "flour-item.png")
).convert_alpha()

milk_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "milk-item.png")
).convert_alpha()

butter_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "butter-item.png")
).convert_alpha()

sugar_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "sugar-item.png")
).convert_alpha()

strawberries_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "strawberry-item.png")
).convert_alpha()

eggs_item_img = pygame.image.load(
    os.path.join("assets", "ingr", "eggs-item.png")
).convert_alpha()

chopped_strawberries_img = pygame.image.load(
    os.path.join("assets", "ingr", "chopped-strawberries.png")
).convert_alpha()

chopped_butter_img = pygame.image.load(
    os.path.join("assets", "ingr", "chopped-butter-item.png")
).convert_alpha()

cake_batter_img = pygame.image.load(
    os.path.join("assets", "ingr", "cake-batter.png")
).convert_alpha()

baked_cake_img = pygame.image.load(
    os.path.join("assets", "ingr", "finished-cake.png")
).convert_alpha()

strawberry_frosting_img = pygame.image.load(
    os.path.join("assets", "ingr", "frosting.png")
).convert_alpha()

unfrosted_cake_img = pygame.image.load(
    os.path.join("assets", "ingr", "unfinished-cake.png")
).convert_alpha()

ingredient_images = {
    "Flour": flour_item_img,
    "Milk": milk_item_img,
    "Butter": butter_item_img,
    "Sugar": sugar_item_img,
    "Strawberries": strawberries_item_img,
    "Eggs": eggs_item_img,
    "Chopped Strawberries": chopped_strawberries_img,
    "Chopped Butter": chopped_butter_img,
    "Unfrosted Cake": unfrosted_cake_img,
    "Cake Batter": cake_batter_img,
    "Strawberry Cake": baked_cake_img,
    "Strawberry Frosting": strawberry_frosting_img,
}

obstacles = [top_left_corner, top_right_corner, bottom_right_corner, bottom_left_corner,
             takeout_counter, flour, fridge, oven, top_counter, butter, cutting, mixing, 
             bottom_counter, sugar, strawberries, egg, bottom1_space, 
             middle1, middle2, middle3, trash, left_counter]

table_contents = {
    "takeout": None, 
    "flour": "Flour", 
    "fridge": "Milk", 
    "oven": None,
    "butter": "Butter", 
    "cutting": None,
    "mixing": None,
    "sugar": "Sugar", 
    "strawberries": "Strawberries", 
    "eggs": "Eggs", 
    "middle1": None, 
    "middle2": None, 
    "middle3": None, 
    "trash": "TRASH",
    "left_counter": None
}

# player1
player1_x = 202
player1_y = 300
p1_vx = 0.0
p1_vy = 0.0
p1_direction = "down"

# player2
player2_x = 425
player2_y = 300 
p2_vx = 0.0
p2_vy = 0.0
p2_direction = "down"

# create semi transparent dark overlay once to prevent lag 
dark_overlay = pygame.Surface((screen_width, screen_height))
dark_overlay.set_alpha(200)
dark_overlay.fill((0, 0, 0))

# initialize timer & game state 
total_time = 120  # 2 min
start_ticks = None
pause_start = 0 
total_paused_time = 0 
game_state = "START_SCREEN"  # "START_SCREEN", "RECIPE_OVERLAY", "PLAYING", "WIN", "LOSE"
cake_delivered = False
time_left = total_time

# display boxes
recipeBox = pygame.Rect(0, 0, 90, 90)
timeBox = pygame.Rect(250, 0, 150, 70)

# buttons and background
start_button_rect = pygame.Rect(
    screen_width // 2 - 100,
    screen_height // 2 + 80,
    200, 
    50
)
close_recipe_rect = pygame.Rect(screen_width // 2 - 75, screen_height - 100, 150, 45)
recipe_box_bg = pygame.Rect(50, 40, screen_width - 100, screen_height - 100)
retry_button_rect = pygame.Rect(screen_width // 2 - 75, screen_height // 2 + 30, 150, 45)

recipe_text_list = [
    "STRAWBERRY CAKE RECIPE",
    "", 
    "1. Chop Strawberries at Cutting Station",
    "2. Mix Flour + Sugar + Butter + Eggs = Cake Batter",
    "3. Bake Batter in Oven = Baked Cake", 
    "4. Mix Strawberry Mix + Butter + Sugar = ",
    " Strawberry Frosting",
    "5. Combine Baked Cake + Frosting at any counter",
    "6. Deliver finished cake to TAKEOUT!"
]

def reset_game():
    """resets all player positions, timer, holdings, and table contents"""
    global player1_x, player1_y, player2_x, player2_y, p1_vx, p1_vy, p2_vx, p2_vy
    global p1_holding, p2_holding, p1_interacted, p2_interacted
    global start_ticks, pause_start, total_paused_time, game_state, cake_delivered, table_contents
    global chop_counters, mixing_timer, oven_timer

    chop_counters = {"cutting": 0}
    mixing_timer = {"start_time": None}
    oven_timer = {"start_time": None}

    # player1
    player1_x = 202
    player1_y = 300
    p1_vx = 0.0
    p1_vy = 0.0

    # player2
    player2_x = 425
    player2_y = 300 
    p2_vx = 0.0
    p2_vy = 0.0
    
    p1_holding = None
    p2_holding = None

    p1_interacted = False
    p2_interacted = False

    start_ticks = None
    pause_start = 0
    total_paused_time = 0
    game_state = "RECIPE_OVERLAY"

    table_contents = {
        "takeout": None, 
        "flour": "Flour", 
        "fridge": "Milk", 
        "oven": None,
        "butter": "Butter", 
        "cutting": None,
        "mixing": None,
        "sugar": "Sugar", 
        "strawberries": "Strawberries", 
        "eggs": "Eggs", 
        "middle1": None, 
        "middle2": None, 
        "middle3": None, 
        "trash": "TRASH",
        "left_counter": None
    }


async def main():
    global running, game_state, cake_delivered, time_left, start_ticks, pause_start, total_paused_time
    global player1_x, player1_y, player2_x, player2_y, p1_vx, p1_vy, p2_vx, p2_vy
    global p1_direction, p2_direction, p1_frame, p2_frame, p1_last_update, p2_last_update
    global p1_holding, p2_holding, p1_interacted, p2_interacted
    global table_contents, chop_counters, mixing_timer, oven_timer

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: 
                running = False 

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_pos = event.pos

                # start screen
                if (
                    game_state == "START_SCREEN" and
                    start_button_rect.collidepoint(mouse_pos)
                ):
                    game_state = "RECIPE_OVERLAY"
                # recipe overlay -> close and start / resume the game 
                elif (
                    game_state == "RECIPE_OVERLAY" and 
                    close_recipe_rect.collidepoint(mouse_pos)
                ):
                    if start_ticks is None:
                        start_ticks = pygame.time.get_ticks()
                        total_paused_time = 0
                    else:
                        total_paused_time += (pygame.time.get_ticks() - pause_start)
                    game_state = "PLAYING"
                # PLAYING -> click top left box to pause and read recipe again
                elif (
                    game_state == "PLAYING" and recipeBox.collidepoint(mouse_pos)
                ):
                    pause_start = pygame.time.get_ticks()
                    game_state = "RECIPE_OVERLAY"
                # game over -> retry button
                elif (
                    game_state in ["WIN", "LOSE"] and retry_button_rect.collidepoint(mouse_pos)
                ):
                    reset_game()
                    game_state = "RECIPE_OVERLAY"

            # handle retry button click
            if event.type == pygame.MOUSEBUTTONDOWN and game_state != "PLAYING":
                if retry_button_rect.collidepoint(event.pos):
                    reset_game()

        # timer 
        if game_state == "PLAYING":
            if start_ticks is not None:
                seconds_passed = (pygame.time.get_ticks() - start_ticks - total_paused_time) // 1000
            time_left = max(0, total_time - seconds_passed)

            # immediate win condition
            if cake_delivered:
                game_state = "WIN"
            # timeout check
            elif time_left == 0:
                game_state = "LOSE"

            # timer check for mixing timer
            if mixing_timer["start_time"] is not None:
                elapsed = pygame.time.get_ticks() - mixing_timer["start_time"]
                if elapsed >= 5000:
                    if table_contents["mixing"] == "MIXING_BATTER":
                        table_contents["mixing"] = "Cake Batter"
                    elif table_contents["mixing"] == "MIXING_FROSTING":
                        table_contents["mixing"] = "Strawberry Frosting"
                    mixing_timer["start_time"] = None

            # timer check for oven
            if oven_timer["start_time"] is not None:
                elapsed_oven = pygame.time.get_ticks() - oven_timer["start_time"]
                if elapsed_oven >= 7000:
                    table_contents["oven"] = "Unfrosted Cake"
                    oven_timer["start_time"] = None

            # inputs
            keys = pygame.key.get_pressed()

            # player1 movement input
            if keys[pygame.K_w]: p1_vy -= acce
            if keys[pygame.K_s]: p1_vy += acce
            if keys[pygame.K_a]: p1_vx -= acce
            if keys[pygame.K_d]: p1_vx += acce

            # player2 movement input
            if keys[pygame.K_UP]:    p2_vy -= acce
            if keys[pygame.K_DOWN]:  p2_vy += acce
            if keys[pygame.K_LEFT]:  p2_vx -= acce
            if keys[pygame.K_RIGHT]: p2_vx += acce

            # apply friction
            p1_vx *= friction; p1_vy *= friction
            p2_vx *= friction; p2_vy *= friction

            # cap speed P1
            p1_speed = math.hypot(p1_vx, p1_vy)
            if p1_speed > max_speed:
                p1_vx = (p1_vx / p1_speed) * max_speed
                p1_vy = (p1_vy / p1_speed) * max_speed

            # cap speed P2
            p2_speed = math.hypot(p2_vx, p2_vy)
            if p2_speed > max_speed:
                p2_vx = (p2_vx / p2_speed) * max_speed
                p2_vy = (p2_vy / p2_speed) * max_speed

            # execute movement and check walls smoothly 
            player1_x, player1_y, p1_vx, p1_vy = wall_collision(player1_x, player1_y, p1_vx, p1_vy, radius, obstacles)
            player2_x, player2_y, p2_vx, p2_vy = wall_collision(player2_x, player2_y, p2_vx, p2_vy, radius, obstacles)

            # momentum & player collisions
            dx = player2_x - player1_x
            dy = player2_y - player1_y
            distance = math.hypot(dx, dy)
            minDis = radius * 2

            if distance < minDis:
                if distance == 0: distance = 0.1 
                overlap = minDis - distance 

                # calc push vectors
                push_x = (dx / distance) * (overlap / 2)
                push_y = (dy / distance) * (overlap / 2)

                # apply push apart safely w/o pushing into walls
                player1_x -= push_x
                player1_y -= push_y
                player2_x += push_x
                player2_y += push_y

                # avoid phasing out
                for p_num, (px, py) in enumerate([(player1_x, player1_y), (player2_x, player2_y)], start=1):
                    p_rect = pygame.Rect(px - radius, py - radius, radius * 2, radius * 2)
                    for obstacle in obstacles:
                        if p_rect.colliderect(obstacle):
                            if p_num == 1:
                                player1_x += push_x
                                player1_y += push_y
                            else:
                                player2_x -= push_x
                                player2_y -= push_y
                            break

                # elastic impulse kinetic energy bounce formulas
                nx = dx / distance
                ny = dy / distance
                kx = p1_vx - p2_vx
                ky = p1_vy - p2_vy
                p = 2 * (nx * kx + ny * ky) / (mass + mass)

                p1_vx -= p * mass * nx
                p1_vy -= p * mass * ny
                p2_vx += p * mass * nx 
                p2_vy += p * mass * ny

            # animation
            current_time = pygame.time.get_ticks()

            if p1_vy < -0.1:
                p1_direction = "up"
            elif p1_vy > 0.1:
                p1_direction = "down"
            elif p1_vx < -0.1:
                p1_direction = "left"
            elif p1_vx > 0.1: 
                p1_direction = "right"
            
            if p1_vy < -0.1:
                if current_time - p1_last_update >= p1_animation_speed:
                    p1_frame = (p1_frame + 1) % len(p1_walk_up)
                    p1_last_update = current_time
            elif p1_vy > 0.1:
                if current_time - p1_last_update >= p1_animation_speed:
                    p1_frame = (p1_frame + 1) % len(p1_walk_down)
                    p1_last_update = current_time
            elif p1_vx < -0.1:
                if current_time - p1_last_update >= p1_animation_speed:
                    p1_frame = (p1_frame + 1) % len(p1_walk_left)
                    p1_last_update = current_time
            elif p1_vx > 0.1:
                if current_time - p1_last_update >= p1_animation_speed:
                    p1_frame = (p1_frame + 1) % len(p1_walk_right)
                    p1_last_update = current_time
            else:
                p1_frame = 0

            if p2_vy < -0.1:
                p2_direction = "up"
            elif p2_vy > 0.1:
                p2_direction = "down"
            elif p2_vx < -0.1:
                p2_direction = "left"
            elif p2_vx > 0.1:
                p2_direction = "right"

            if p2_vy < -0.1:
                if current_time - p2_last_update >= p2_animation_speed:
                    p2_frame = (p2_frame + 1) % len(p2_walk_up)
                    p2_last_update = current_time
            elif p2_vy > 0.1:
                if current_time - p2_last_update >= p2_animation_speed:
                    p2_frame = (p2_frame + 1) % len(p2_walk_down)
                    p2_last_update = current_time
            elif p2_vx < -0.1:
                if current_time - p2_last_update >= p2_animation_speed:
                    p2_frame = (p2_frame + 1) % len(p2_walk_left)
                    p2_last_update = current_time
            elif p2_vx > 0.1:
                if current_time - p2_last_update >= p2_animation_speed:
                    p2_frame = (p2_frame + 1) % len(p2_walk_right)
                    p2_last_update = current_time
            else:
                p2_frame = 0
            
            # pickup and drop
            # p1 clicks e
            p1_holding, p1_interacted, p1_delivered = handle_inter(
                player1_x, player1_y, radius, p1_holding, keys[pygame.K_e], p1_interacted, 
                obstacles, table_contents, middle1, middle2, middle3, takeout_counter, flour, fridge,
                oven, butter, cutting, mixing, sugar, strawberries, egg, trash, left_counter, chop_counters, mixing_timer, oven_timer
            )

            # Player 2 Interaction (Press RETURN/ENTER)
            p2_holding, p2_interacted, p2_delivered = handle_inter(
                player2_x, player2_y, radius, p2_holding, keys[pygame.K_RETURN], p2_interacted, 
                obstacles, table_contents, middle1, middle2, middle3, takeout_counter, flour, fridge, 
                oven, butter, cutting, mixing, sugar, strawberries, egg, trash, left_counter, chop_counters, mixing_timer, oven_timer
            )

            # win condition check
            if p1_delivered or p2_delivered:
                cake_delivered = True

        # DRAWING SYSTEM
        screen.blit(background_img, (0, 0))

        # p1 render
        if p1_vy < -0.1:
            current_image = p1_walk_up[p1_frame % len(p1_walk_up)]
        elif p1_vy > 0.1:
            current_image = p1_walk_down[p1_frame % len(p1_walk_down)]
        elif p1_vx < -0.1:
            current_image = p1_walk_left[p1_frame % len(p1_walk_left)]
        elif p1_vx > 0.1:
            current_image = p1_walk_right[p1_frame % len(p1_walk_right)]
        else:
            if p1_direction == "up":
                current_image = p1_idle_up
            elif p1_direction == "left":
                current_image = p1_idle_left
            elif p1_direction == "right":
                current_image = p1_idle_right
            else:
                current_image = player1_img

        p1_rect = current_image.get_rect(
            midbottom=(int(player1_x), int(player1_y) + radius)
        )
        screen.blit(current_image, p1_rect)

        # p2 render
        if p2_vy < -0.1:
            current_image = p2_walk_up[p2_frame % len(p2_walk_up)]
        elif p2_vy > 0.1:
            current_image = p2_walk_down[p2_frame % len(p2_walk_down)]
        elif p2_vx < -0.1:
            current_image = p2_walk_left[p2_frame % len(p2_walk_left)]
        elif p2_vx > 0.1:
            current_image = p2_walk_right[p2_frame % len(p2_walk_right)]
        else:
            if p2_direction == "up":
                current_image = p2_idle_up
            elif p2_direction == "left":
                current_image = p2_idle_left
            elif p2_direction == "right":
                current_image = p2_idle_right
            else:
                current_image = player2_img

        p2_rect = current_image.get_rect(
            midbottom=(int(player2_x), int(player2_y) + radius)
        )
        screen.blit(current_image, p2_rect)

        pygame.draw.rect(screen, "brown", top_left_corner)
        screen.blit(top_left, top_left_corner)

        pygame.draw.rect(screen, "brown", top_right_corner)
        screen.blit(top_right_img, top_right_corner)

        pygame.draw.rect(screen, "brown", bottom_right_corner)
        screen.blit(bottom_right_img, bottom_right_corner)

        pygame.draw.rect(screen, "brown", bottom_left_corner)

        # left draw
        pygame.draw.rect(screen, "pink", left_counter)
        screen.blit(left_counter_img, left_counter)

        pygame.draw.rect(screen, "red", takeout_counter)
        screen.blit(takeout_img, takeout_counter)

        # top draw
        pygame.draw.rect(screen, "purple", flour)
        screen.blit(flour_img, flour)
        pygame.draw.rect(screen, "blue", fridge)
        screen.blit(fridge_img, fridge)

        pygame.draw.rect(screen, "black", oven)
        screen.blit(oven_img, oven)

        pygame.draw.rect(screen, "hotpink", top_counter)
        screen.blit(top_counter_img, top_counter)

        # right draw
        pygame.draw.rect(screen, "orange", butter)
        screen.blit(butter_img, butter)
        pygame.draw.rect(screen, "yellow", cutting)
        screen.blit(cutting_img, cutting)
        pygame.draw.rect(screen, "pink", mixing)
        screen.blit(mixing_img, mixing)
        pygame.draw.rect(screen, "hotpink", bottom_counter)
        screen.blit(bottom_counter_img, bottom_counter)

        # bottom draw
        pygame.draw.rect(screen, "grey", sugar)
        screen.blit(sugar_img, sugar)

        pygame.draw.rect(screen, "red", strawberries)
        screen.blit(berry_img, strawberries)

        pygame.draw.rect(screen, "yellow", egg)
        screen.blit(egg_img, egg)
        pygame.draw.rect(screen, "pink", bottom1_space)
        screen.blit(bottom1_space_img, bottom1_space)

        pygame.draw.rect(screen, "black", trash)
        screen.blit(trash_img, trash)

        # middle draw
        pygame.draw.rect(screen, "green", middle1)
        screen.blit(middle1_img, middle1)

        pygame.draw.rect(screen, "orange", middle2)
        screen.blit(middle2_img, middle2)

        pygame.draw.rect(screen, "blue", middle3)
        screen.blit(middle3_img, middle3)

        # boxes
        pygame.draw.rect(screen, "lightpink", recipeBox)
        pygame.draw.rect(screen, "lightpink", timeBox)

        for location, item in table_contents.items():
            if item is not None:
                target_rect = None
                if location == "flour": target_rect = flour
                elif location == "fridge": target_rect = fridge
                elif location == "oven": target_rect = oven
                elif location == "butter": target_rect = butter
                elif location == "cutting": target_rect = cutting
                elif location == "mixing": target_rect = mixing
                elif location == "sugar": target_rect = sugar
                elif location == "strawberries": target_rect = strawberries
                elif location == "eggs": target_rect = egg
                elif location == "middle1": target_rect = middle1
                elif location == "middle2": target_rect = middle2
                elif location == "middle3": target_rect = middle3
                elif location == "left_counter": target_rect = left_counter
                elif location == "takeout": target_rect = takeout_counter
                elif location == "trash": target_rect = trash

                # MIXING TIMER
                if location == "mixing" and table_contents["mixing"] in ["MIXING_BATTER", "MIXING_FROSTING"]:
                    if mixing_timer["start_time"] is not None:
                        secs_left_mix = max(
                            1,
                            5 - (pygame.time.get_ticks() - mixing_timer["start_time"]) // 1000
                        )
                        text_surface = font.render(
                            f"Mixing... {secs_left_mix}s",
                            True,
                            "white"
                        )
                    else:
                        text_surface = font.render(
                            "Mixing...",
                            True,
                            "white"
                        )

                    if target_rect:
                        text_rect = text_surface.get_rect(center=target_rect.center)
                        screen.blit(text_surface, text_rect)

                # BAKING TIMER
                elif location == "oven" and table_contents["oven"] == "BAKING_CAKE":
                    if oven_timer["start_time"] is not None:
                        secs_left_oven = max(
                            1,
                            7 - (pygame.time.get_ticks() - oven_timer["start_time"]) // 1000
                        )
                        text_surface = font.render(
                            f"Baking... {secs_left_oven}s",
                            True,
                            "white"
                        )
                    else:
                        text_surface = font.render(
                            "Baking...",
                            True,
                            "white"
                        )

                    if target_rect:
                        text_rect = text_surface.get_rect(center=target_rect.center)
                        screen.blit(text_surface, text_rect)

                # EVERYTHING ELSE -> SHOW THE ITEM PICTURE
                else:
                    original_counter_items = {
                        "flour": "Flour",
                        "fridge": "Milk",
                        "butter": "Butter",
                        "sugar": "Sugar",
                        "strawberries": "Strawberries",
                        "eggs": "Eggs",
                    }

                    if location in original_counter_items and item == original_counter_items[location]:
                        continue

                    item_img = ingredient_images.get(item)

                    if item_img is not None and target_rect:
                        item_rect = item_img.get_rect(
                            center=target_rect.center
                        )
                        screen.blit(item_img, item_rect)

        # draw ui boxes and timer text
        pygame.draw.rect(screen, "lightpink", recipeBox, border_radius=8)
        pygame.draw.rect(screen, "white", recipeBox, width=2, border_radius=8)

        recipe_btn_txt = font.render("RECIPE", True, "black")
        screen.blit(recipe_btn_txt, recipe_btn_txt.get_rect(center=recipeBox.center))

        pygame.draw.rect(screen, "lightpink", timeBox)
        pygame.draw.rect(screen, "white", timeBox, width=2)

        # draw timer text INSIDE the timebox 
        mins = time_left // 60
        secs = time_left % 60

        timer_font = pygame.font.Font(
            os.path.join("assets", "font", "Pixelify_Sans", "PixelifySans-VariableFont_wght.ttf"),
            28
        )
        timer_text = timer_font.render(f"{mins:02d}:{secs:02d}", True, "black")
        timer_rect = timer_text.get_rect(center=timeBox.center)
        screen.blit(timer_text, timer_rect)

        # screen overlays
        if game_state == "START_SCREEN":
            screen.blit(dark_overlay, (0, 0))

            title_rect = title_img.get_rect(
                center=(screen_width // 2, 180)
            )
            screen.blit(title_img, title_rect)

            pygame.draw.rect(
                screen,
                "hotpink",
                start_button_rect,
                border_radius=10
            )

            start_txt = font.render(
                "START GAME",
                True,
                "white"
            )

            screen.blit(
                start_txt,
                start_txt.get_rect(
                    center=start_button_rect.center
                )
            )

        elif game_state == "RECIPE_OVERLAY":
            screen.blit(dark_overlay, (0, 0))

            pygame.draw.rect(screen, (255, 218, 224), recipe_box_bg, border_radius=15)
            pygame.draw.rect(screen, "hotpink", recipe_box_bg, width=4, border_radius=15)

            for i, line in enumerate(recipe_text_list):
                line_surface = font.render(
                    line, True, "black" if i != 0 else "hotpink"
                )
                screen.blit(line_surface, (recipe_box_bg.x + 30, recipe_box_bg.y + 30 + (i * 32)))

            pygame.draw.rect(
                screen, "hotpink", close_recipe_rect, border_radius=8
            )
            close_txt = font.render("Continue", True, "white")
            screen.blit(close_txt, close_txt.get_rect(center=close_recipe_rect.center))

        elif game_state in ["WIN", "LOSE"]:
            screen.blit(dark_overlay, (0, 0))

            if game_state == "WIN":
                ending_img = win_screen_img
            else:
                ending_img = lose_screen_img

            ending_rect = ending_img.get_rect(
                center=(screen_width // 2, 225)
            )
            screen.blit(ending_img, ending_rect)

            pygame.draw.rect(
                screen,
                "hotpink",
                retry_button_rect,
                border_radius=10
            )

            pygame.draw.rect(
                screen,
                "white",
                retry_button_rect,
                width=2,
                border_radius=10
            )

            retry_txt = font.render(
                "TRY AGAIN",
                True,
                "white"
            )

            screen.blit(
                retry_txt,
                retry_txt.get_rect(
                    center=retry_button_rect.center
                )
            )

        pygame.display.flip()
        clock.tick(60)

        # Essential yield for pygbag web compatibility
        await asyncio.sleep(0)

    pygame.quit()

# Entry point
asyncio.run(main())