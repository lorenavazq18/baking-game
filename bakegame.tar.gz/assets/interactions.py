import pygame

# Keeps track of ingredients inside the mixing bowl
mixing_bowl = []


def handle_inter(
    player_x, player_y, radius, holding, key_pressed, already_interacted,
    obstacles, table_contents,
    middle1, middle2, middle3, takeout_counter, flour, fridge,
    oven, butter, cutting, mixing, sugar, strawberries, egg, trash,
    left_counter, chop_counters, mixing_timer, oven_timer
):
    global mixing_bowl

    cake_delivered = False

    # ---------------------------------------------------------
    # ONLY interact once per key press
    # ---------------------------------------------------------
    if key_pressed:

        if not already_interacted:
            already_interacted = True

            # Player's interaction/reach area
            reach_rect = pygame.Rect(
                player_x - radius,
                player_y - radius,
                radius * 2,
                radius * 2
            ).inflate(10, 10)

            # -------------------------------------------------
            # Find ALL nearby known stations
            #
            # This is better than simply using the first obstacle
            # in the obstacles list. It prevents one player from
            # accidentally interacting with the wrong counter.
            # -------------------------------------------------
            station_rects = [
                ("middle1", middle1),
                ("middle2", middle2),
                ("middle3", middle3),
                ("takeout", takeout_counter),
                ("flour", flour),
                ("fridge", fridge),
                ("oven", oven),
                ("butter", butter),
                ("cutting", cutting),
                ("mixing", mixing),
                ("sugar", sugar),
                ("strawberries", strawberries),
                ("eggs", egg),
                ("trash", trash),
                ("left_counter", left_counter),
            ]

            nearby_stations = []

            for location_key, station_rect in station_rects:
                if reach_rect.colliderect(station_rect):
                    # Distance from player to station center
                    dx = player_x - station_rect.centerx
                    dy = player_y - station_rect.centery
                    distance = dx * dx + dy * dy

                    nearby_stations.append(
                        (distance, location_key, station_rect)
                    )

            # Nothing close enough to interact with
            if not nearby_stations:
                return holding, already_interacted, cake_delivered

            # Use the closest station instead of whichever obstacle
            # happens to appear first in the obstacles list.
            nearby_stations.sort(key=lambda item: item[0])

            _, location_key, _ = nearby_stations[0]

            # =================================================
            # 1. TRASH
            # =================================================
            if location_key == "trash":

                if holding is not None:
                    holding = None

                return holding, already_interacted, cake_delivered

            # =================================================
            # 2. CUTTING BOARD
            # =================================================
            if location_key == "cutting":

                item_on_board = table_contents["cutting"]

                # ---------------------------------------------
                # Put whole strawberries or butter on board
                # ---------------------------------------------
                if (
                    holding in ["Strawberries", "Butter"]
                    and item_on_board is None
                ):
                    table_contents["cutting"] = holding
                    holding = None
                    chop_counters["cutting"] = 0

                    return holding, already_interacted, cake_delivered

                # ---------------------------------------------
                # Chop strawberries or butter
                # ---------------------------------------------
                elif (
                    holding is None
                    and item_on_board in ["Strawberries", "Butter"]
                ):
                    chop_counters["cutting"] += 1

                    # Three clicks = chopped ingredient
                    if chop_counters["cutting"] >= 3:

                        if item_on_board == "Strawberries":
                            table_contents["cutting"] = "Chopped Strawberries"

                        elif item_on_board == "Butter":
                            table_contents["cutting"] = "Chopped Butter"

                        chop_counters["cutting"] = 0

                    return holding, already_interacted, cake_delivered

                # ---------------------------------------------
                # Pick up chopped ingredient
                # ---------------------------------------------
                elif (
                    holding is None
                    and item_on_board is not None
                ):
                    holding = item_on_board
                    table_contents["cutting"] = None
                    chop_counters["cutting"] = 0

                    return holding, already_interacted, cake_delivered

            # =================================================
            # 3. MIXING BOWL
            # =================================================
            if location_key == "mixing":

                # ---------------------------------------------
                # Add ingredients to mixing bowl
                # ---------------------------------------------
                if holding in [
                    "Flour",
                    "Sugar",
                    "Chopped Butter",
                    "Eggs",
                    "Chopped Strawberries"
                ]:

                    if table_contents["mixing"] is None:

                        mixing_bowl.append(holding)
                        holding = None

                        # -------------------------------------
                        # Cake batter recipe
                        # Flour + Sugar + Chopped Butter + Eggs
                        # -------------------------------------
                        batter_reqs = [
                            "Flour",
                            "Sugar",
                            "Chopped Butter",
                            "Eggs"
                        ]

                        if all(item in mixing_bowl for item in batter_reqs):

                            table_contents["mixing"] = "MIXING_BATTER"

                            mixing_timer["start_time"] = pygame.time.get_ticks()

                            mixing_bowl = []

                        # -------------------------------------
                        # Strawberry frosting recipe
                        # Chopped Strawberries + Chopped Butter + Sugar
                        # -------------------------------------
                        frosting_reqs = [
                            "Chopped Strawberries",
                            "Chopped Butter",
                            "Sugar"
                        ]

                        if all(item in mixing_bowl for item in frosting_reqs):

                            table_contents["mixing"] = "MIXING_FROSTING"

                            mixing_timer["start_time"] = pygame.time.get_ticks()

                            mixing_bowl = []

                    return holding, already_interacted, cake_delivered

                # ---------------------------------------------
                # Pick up finished batter/frosting
                # ---------------------------------------------
                elif (
                    holding is None
                    and table_contents["mixing"]
                    in ["Cake Batter", "Strawberry Frosting"]
                ):

                    holding = table_contents["mixing"]
                    table_contents["mixing"] = None

                    return holding, already_interacted, cake_delivered

            # =================================================
            # 4. OVEN
            # =================================================
            if location_key == "oven":

                # ---------------------------------------------
                # Put cake batter into oven
                # ---------------------------------------------
                if (
                    holding == "Cake Batter"
                    and table_contents["oven"] is None
                ):

                    table_contents["oven"] = "BAKING_CAKE"

                    oven_timer["start_time"] = pygame.time.get_ticks()

                    holding = None

                    return holding, already_interacted, cake_delivered

                # ---------------------------------------------
                # Pick up finished UNFROSTED cake
                # ---------------------------------------------
                elif (
                    holding is None
                    and table_contents["oven"] == "Unfrosted Cake"
                ):

                    holding = "Unfrosted Cake"

                    table_contents["oven"] = None

                    return holding, already_interacted, cake_delivered

            # =================================================
            # 5. ASSEMBLY
            #
            # Cake + frosting can be combined either way:
            #
            # Player holding frosting + cake on counter
            # OR
            # Player holding cake + frosting on counter
            # =================================================

            # Player is holding frosting
            # Counter has unfrosted cake
            if (
                holding == "Strawberry Frosting"
                and table_contents.get(location_key) == "Unfrosted Cake"
            ):

                table_contents[location_key] = "Strawberry Cake"

                holding = None

                return holding, already_interacted, cake_delivered

            # Player is holding cake
            # Counter has frosting
            if (
                holding == "Unfrosted Cake"
                and table_contents.get(location_key) == "Strawberry Frosting"
            ):

                table_contents[location_key] = "Strawberry Cake"

                holding = None

                return holding, already_interacted, cake_delivered

            # =================================================
            # 6. TAKEOUT / SERVE
            # =================================================
            if (
                location_key == "takeout"
                and holding == "Strawberry Cake"
            ):

                holding = None
                cake_delivered = True

                return holding, already_interacted, cake_delivered

            # =================================================
            # 7. GENERAL PICKUP / DROP
            # =================================================

            # These stations always have their ingredient available.
            infinite_sources = [
                "flour",
                "fridge",
                "butter",
                "sugar",
                "strawberries",
                "eggs"
            ]

            # ---------------------------------------------
            # Pick something up from a counter
            # ---------------------------------------------
            if (
                holding is None
                and table_contents.get(location_key) is not None
            ):

                holding = table_contents[location_key]

                # Remove item from normal counters.
                # Infinite ingredient stations keep their item.
                if location_key not in infinite_sources:
                    table_contents[location_key] = None

                return holding, already_interacted, cake_delivered

            # ---------------------------------------------
            # Put something down on an empty counter
            # ---------------------------------------------
            elif (
                holding is not None
                and table_contents.get(location_key) is None
            ):

                if location_key not in infinite_sources:

                    table_contents[location_key] = holding
                    holding = None

                return holding, already_interacted, cake_delivered

    # ---------------------------------------------------------
    # Key released -> allow another interaction
    # ---------------------------------------------------------
    else:
        already_interacted = False

    return holding, already_interacted, cake_delivered