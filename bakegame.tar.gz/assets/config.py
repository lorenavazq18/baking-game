import pygame

#screen configs
screen_width = 640
screen_height = 600
FPS = 60

#physics parameters 
friction = 0.85
acce = 0.8
max_speed = 3.5 #6.0
mass = 1.0
radius = 32 #25

#layout dimensions
#middle_data = [240, 300, 150, 50]
#left_data   = [100, 150, 50, 350]
#right_data  = [490, 150, 50, 350]
#upper_data  = [100, 120, 440, 50]
#lower_data  = [100, 500, 440, 50]


top_left_corner_data = [100, 120, 50 ,50] #pic
top_right_corner_data = [490, 120, 50, 50] 
bottom_right_corner_data = [490, 500, 50, 50]
bottom_left_corner_data = [100, 500, 50, 50]

#left
left_counter_data = [100, 170, 50, 100] #pic
takeout_data = [100, 270, 50, 280] #[100, 170, 50, 300 me thinks] #pic


#top
flour_data = [150, 120, 80, 50] #pic
fridge_data = [230, 120, 100, 50] #pic
oven_data = [330, 120, 100, 50] #pic
top_counter_data = [430, 120, 60, 50] 

#right
butter_data = [490, 170, 50, 60]
cutting_data = [490, 230, 50, 100]
mixing_data = [490, 330, 50, 100]
bottom_counter_data = [490, 430, 50, 70] #430 + 70 = 500 #pic

#bottom
sugar_data = [150, 500, 60, 50] #pic
strawberries_data = [210, 500, 60, 50] #pic
egg_data = [270, 500, 60, 50] #pic
bottom_counter_space1_data = [330, 500, 110, 50]
trash_data = [440, 500, 50, 50] #swapped trash for counter


#middle
middle_counter1_data = [240, 300, 50, 50]
middle_counter2_data = [290, 300, 50, 50]
middle_counter3_data = [340, 300, 50, 50]