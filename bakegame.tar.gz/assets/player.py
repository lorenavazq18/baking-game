import pygame
#player class 

class Player:
    def __init__(self, x, y, image, radius=25):
        self.x = x
        self.y = y

        self.vx = 0.0
        self.vy = 0.0

        self.image = image
        self.radius = radius

        self.carrying = None
        self.direction = "down"

        #animation images
        self.idle_frames = idle_frames
        self.walk_frames = walk_frames

        #animation settings
        self.frame_index = 0
        self.frame_duration = 140
        self.last_frame_time = pygame.time.get_ticks()

        self.moving = False
    def update_animation(self):
        self.moving = abs(self.vx) > 0.1 or abs(self.vy) > 0.1

        #direction?
        if self.moving:
            if abs(self.vx) > abs(self.vy):
                self.direction = "right" if self.vx > 0 else "left"
            else:
                self.direction = "down" if self.vy > 0 else "up"

            current_time = pygame.time.get_ticks()

            if current_time - self.last_frame_time >= self.frame_duration:
                self.frame_index = (
                    self.frame_index + 1
                ) % len(self.walk_frames[self.direction])

                self.last_frame_time = current_time
        else:
            self.frame_index = 0


    def draw(self, screen):
        if self.moving:
            image = self.walk_frames[self.direction][self.frame_index]
        else:
            image = self.idle_frames[self.direction]
        rect = image.get_rect(
            midbottom=(int(self.x), int(self.y) + self.radius)     
         )
        screen.blit(image, rect)

